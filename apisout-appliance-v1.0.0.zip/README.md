# APISout Data Normalization Engine (v1.0.0)
### Developed by Apis Labs LLC

APISout is a high-throughput, completely standalone, and containerized data normalization microservice appliance. It is engineered to ingest unstructured JSON data streams, sanitize messy unicode noise (such as currency symbols, commas, and unformatted text), and cast the fields cleanly into native computer data types based on declarative configuration matrices.

The product runs 100% locally and offline on your corporate infrastructure without phoning home or requiring outside internet access.

---

## [SYSTEM COMPONENTS] Architecture Overview
1. APISout Core Engine: A high-performance FastAPI/Uvicorn REST engine handling type-casting matrices.
2. APISout Directory Daemon: An asynchronous, non-blocking background folder observer that automates file normalization.

---

## [DEPLOYMENT] Quick-Start Standalone Setup

To spin up the entire pre-configured ecosystem on your infrastructure, navigate to this project folder and execute the universal orchestration command:

```bash
sudo docker compose up -d --build
```

### [INTERFACE] Accessing the Graphical Management Control Board
Once the containers initialize, open any web browser on your network and navigate to the embedded local administrative panel to configure template presets, track verification streams, and review active documentation:

http://apisout.local:9001
(Note: Ensure "127.0.0.1 apisout.local" is appended to your /etc/hosts file for local domain routing).

---

## [STORAGE] Custom Directory Folder Configuration

By default, the appliance monitors the local "./drop_zone" folder and outputs clean records to "./normalized_output". 

If your enterprise network requires APISout to monitor custom system storage pools (e.g., an automated storage area network or custom web directories), you do not need to modify the Python source code. You can remap the storage boundaries directly using the "volumes" layer inside docker-compose.yml.

### Example: Mapping Custom Corporate Directories
Open docker-compose.yml and adjust the left-hand side of the colon (host_path:container_path) under the "apisout-watcher" service:

```yaml
  apisout-watcher:
    # ... build settings remain unchanged ...
    volumes:
      # [CUSTOM HOST DIR PATH]  : [INTERNAL APPLIANCE PATH]
      - /mnt/secure_ingress/raw_logs:/app/drop_zone
      - /var/www/normalized_records:/app/normalized_output
```

Run "sudo docker compose up -d" after saving your changes. Docker will instantly bridge your custom host directories straight into the isolated appliance sandbox.

---

## [METRICS] Viewing System Telemetry and Logs

To stream active processing metrics, Pydantic type-validation traces, and infrastructure events concurrently from your containers, execute:

```bash
sudo docker compose logs -f
```

To gracefully shut down the local network bridges and free up system ports:
```bash
sudo docker compose down
```

---
## [LEGAL] Corporate Licensing and Compliance
This software asset and its underlying architecture are proprietary properties managed by Apis Labs LLC. Unauthorized distribution or reverse-engineering of the containerization layers outside of active corporate licensing clauses is strictly prohibited. 

For technical support or procurement adjustments, contact contact@apislabs.net.
