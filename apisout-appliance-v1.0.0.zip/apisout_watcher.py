import asyncio
import os
import json
import aiofiles
import aiohttp
import time

INPUT_FOLDER = "./drop_zone"
OUTPUT_FOLDER = "./normalized_output"
TARGET_URL = "http://apisout-engine:9001/api/v1/apisout/transform"

async def process_file(file_path, session):
    try:
        async with aiofiles.open(file_path, mode='r', encoding='utf-8') as f:
            contents = await f.read()
            raw_json = json.loads(contents)
        
        payload_model = {
            "data": raw_json.get("data", {}),
            "mapping": raw_json.get("mapping", [])
        }

        headers = {"Content-Type": "application/json"}

        async with session.post(TARGET_URL, json=payload_model, headers=headers) as response:
            if response.status == 200:
                response_json = await response.json()
                clean_data = response_json.get("transformed_data", response_json)
                
                out_filename = f"normalized_{os.path.basename(file_path)}"
                out_path = os.path.join(OUTPUT_FOLDER, out_filename)
                
                async with aiofiles.open(out_path, mode='w', encoding='utf-8') as out_f:
                    await out_f.write(json.dumps(clean_data, indent=2, ensure_ascii=False))
                
                os.remove(file_path)
                print(f"[SUCCESS] [APISout Watcher] Cleaned and compiled: {os.path.basename(file_path)}")
            else:
                print(f"[ERROR] [APISout Error {response.status}] Processing rejected for {os.path.basename(file_path)}")
                
    except Exception as e:
        print(f"[WARN] [APISout Exception] Worker engine failure on file {os.path.basename(file_path)}: {str(e)}")

async def main():
    os.makedirs(INPUT_FOLDER, exist_ok=True)
    os.makedirs(OUTPUT_FOLDER, exist_ok=True)

    while True:
        all_files = [os.path.join(INPUT_FOLDER, f) for f in os.listdir(INPUT_FOLDER) if f.endswith('.json')]
        if all_files:
            async with aiohttp.ClientSession() as session:
                tasks = [process_file(path, session) for path in all_files]
                await asyncio.gather(*tasks)
        await asyncio.sleep(1)

if __name__ == "__main__":
    asyncio.run(main())
