import os
import yaml
import uvicorn
from fastapi import FastAPI, HTTPException, status
from fastapi.middleware.cors import CORSMiddleware
from fastapi.responses import HTMLResponse
from pydantic import BaseModel, Field, field_validator
from typing import List, Dict, Any
from transformer import transform_json

app = FastAPI(
    title="APISout Data Normalization Engine",
    version="1.0.0",
    description="Enterprise standalone microservice for high-throughput data parsing and type-casting alignment.",
    docs_url="/apisout/docs",
    redoc_url="/apisout/redoc"
)

app.add_middleware(
    CORSMiddleware,
    allow_origins=["*"],
    allow_credentials=True,
    allow_methods=["POST", "GET"],
    allow_headers=["Content-Type"],
)

class SchemaRule(BaseModel):
    source_key: str = Field(..., min_length=1)
    target_key: str = Field(..., min_length=1)
    type: str = Field(..., min_length=1)

    @field_validator("type")
    @classmethod
    def validate_type_string(cls, value: str) -> str:
        allowed_types = {"integer", "int", "float", "string", "bool", "boolean"}
        clean_type = value.strip().lower()
        if clean_type not in allowed_types:
            raise ValueError(f"Unsupported type: {value}")
        return clean_type

class TransformationPayload(BaseModel):
    data: Dict[str, Any] = Field(...)
    mapping: List[SchemaRule] = Field(...)

@app.post("/api/v1/apisout/transform", status_code=status.HTTP_200_OK)
def execute_apisout_transformation(payload: TransformationPayload):
    try:
        schema_rules = [rule.model_dump() for rule in payload.mapping]
        return transform_json(payload.data, schema_rules)
    except Exception as e:
        raise HTTPException(status_code=500, detail=str(e))

@app.get("/", include_in_schema=False)
def root_auto_redirect():
    from fastapi.responses import RedirectResponse
    return RedirectResponse(url="/apisout/dashboard")

@app.get("/apisout/dashboard", response_class=HTMLResponse)
def get_local_management_dashboard():
    dashboard_file = "dashboard.html"
    if os.path.exists(dashboard_file):
        with open(dashboard_file, "r", encoding="utf-8") as f:
            return f.read()
    return "<h1>APISout Error: Dashboard layout asset missing from container space.</h1>"

if __name__ == "__main__":
    host_ip = "0.0.0.0"
    host_port = 9001
    config_path = "settings.yml"
    if os.path.exists(config_path):
        try:
            with open(config_path, "r") as f:
                config = yaml.safe_load(f)
                if config:
                    host_ip = config.get("host", host_ip)
                    host_port = int(config.get("port", host_port))
        except Exception:
            pass
    print(f"[INFO] Initializing APISout Pipeline Core on -> http://{host_ip}:{host_port}")
    uvicorn.run("engine_core:app", host=host_ip, port=host_port, log_level="info")
