import re
import json

STRIP_CURRENCY_REGEX = re.compile(r'[$,\u00a3\u20ac]')

def clean_integer(value) -> int:
    if isinstance(value, int):
        return value
    if value is None:
        return 0
    val_str = str(value).strip()
    val_str = STRIP_CURRENCY_REGEX.sub("", val_str).replace(",", "")
    if not val_str:
        return 0
    if "." in val_str:
        return int(float(val_str))
    return int(val_str)

def clean_float(value) -> float:
    if isinstance(value, (int, float)):
        return float(value)
    if value is None:
        return 0.0
    clean_val = str(value).strip().replace(",", "")
    clean_val = STRIP_CURRENCY_REGEX.sub("", clean_val)
    if not clean_val:
        return 0.0
    return float(clean_val)

def clean_string(value) -> str:
    if value is None:
        return ""
    return str(value).strip()

def clean_boolean(value) -> bool:
    if isinstance(value, bool):
        return value
    if value is None:
        return False
    return str(value).strip().lower() in ("true", "1", "yes", "on", "active")

def transform_json(raw_data: dict, schema: list) -> dict:
    pristine_data = {}
    for rule in schema:
        source_key = rule.get('source_key')
        target_key = rule.get('target_key')
        target_type = rule.get('type')
        
        if source_key not in raw_data:
            continue
            
        raw_value = raw_data[source_key]
        
        try:
            if target_type in ("integer", "int"):
                pristine_data[target_key] = clean_integer(raw_value)
            elif target_type == "float":
                pristine_data[target_key] = clean_float(raw_value)
            elif target_type == "string":
                pristine_data[target_key] = clean_string(raw_value)
            elif target_type in ("bool", "boolean"):
                pristine_data[target_key] = clean_boolean(raw_value)
            else:
                pristine_data[target_key] = raw_value
        except (ValueError, TypeError):
            pristine_data[target_key] = None
            
    if not pristine_data:
        raise ValueError("Transformation yielded zero valid fields.")
            
    return {
        "status": "success",
        "transformed_data": pristine_data    
    }
